package LaLigaPlus;

public class Equipo {
    private int club_id;
    private String club_name;
    private String city;
    private String stadium_name;

    public Equipo(int club_id, String club_name, String city, String stadium_name) {
        this.club_id = club_id;
        this.club_name = club_name;
        this.city = city;
        this.stadium_name = stadium_name;
    }

    public int getClubId() { return club_id; }
    public Object[] toRow() {
        return new Object[]{club_id, club_name, city, stadium_name};
    }
}
package LaLigaPlus;

public class Jugador {
    private int player_id;
    private String first_name;
    private String last_name;
    private String position;
    private int jersey_number;
    private String nationality;
    private double market_value;
    private int club_id;

    public Jugador(int player_id, String first_name, String last_name, String position,
                   int jersey_number, String nationality, double market_value, int club_id) {
        this.player_id = player_id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.position = position;
        this.jersey_number = jersey_number;
        this.nationality = nationality;
        this.market_value = market_value;
        this.club_id = club_id;
    }

    public int getClubId() { return club_id; }
    public Object[] toRow() {
        return new Object[]{jersey_number, first_name + " " + last_name, position, nationality, market_value + "M€"};
    }
}
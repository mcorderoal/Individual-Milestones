package LaLigaPlus;

public class Entrenador {
    private int coach_id;
    private String first_name;
    private String last_name;
    private String preferred_formation;
    private int experience_years;
    private int club_id;

    public Entrenador(int coach_id, String first_name, String last_name,
                      String preferred_formation, int experience_years, int club_id) {
        this.coach_id = coach_id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.preferred_formation = preferred_formation;
        this.experience_years = experience_years;
        this.club_id = club_id;
    }

    public int getClubId() { return club_id; }
    public Object[] toRow() {
        return new Object[]{first_name + " " + last_name, preferred_formation, experience_years + " años"};
    }
}
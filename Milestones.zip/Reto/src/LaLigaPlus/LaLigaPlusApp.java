package LaLigaPlus;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class LaLigaPlusApp extends JFrame {
    private CardLayout cardLayout = new CardLayout();
    private JPanel contenedor = new JPanel(cardLayout);
    private List<Equipo> listaEquipos = new ArrayList<>();
    private List<Usuario> listaUsuarios = new ArrayList<>();
    private List<Jugador> listaJugadores = new ArrayList<>();
    private List<Entrenador> listaEntrenadores = new ArrayList<>();

    // Asegúrate de poner tu imagen en la carpeta raíz del proyecto
    private final String RUTA_LOGO = "logo_laliga.png";

    public LaLigaPlusApp() {
        setTitle("LaLiga Plus - Gestión Deportiva");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        cargarDatosDesdeBD();

        contenedor.add(panelInicio(), "INICIO");
        contenedor.add(panelLogin(), "LOGIN_FORM");
        contenedor.add(panelRegistro(), "REGISTRO_FORM");
        contenedor.add(panelEquipos(false), "INVITADO");
        contenedor.add(panelEquipos(true), "REGISTRADO");

        add(contenedor);
        setVisible(true);
    }

    private void cargarDatosDesdeBD() {
        // EQUIPOS
        listaEquipos.add(new Equipo(1, "Real Madrid", "Madrid", "Santiago Bernabéu"));
        listaEquipos.add(new Equipo(2, "FC Barcelona", "Barcelona", "Spotify Camp Nou"));
        listaEquipos.add(new Equipo(3, "Atlético de Madrid", "Madrid", "Cívitas Metropolitano"));
        listaEquipos.add(new Equipo(4, "Real Sociedad", "San Sebastián", "Reale Arena"));
        listaEquipos.add(new Equipo(5, "Real Betis", "Sevilla", "Benito Villamarín"));
        listaEquipos.add(new Equipo(6, "Villarreal CF", "Villarreal", "Estadio de la Cerámica"));
        listaEquipos.add(new Equipo(7, "Sevilla FC", "Sevilla", "Ramón Sánchez-Pizjuán"));
        listaEquipos.add(new Equipo(8, "Athletic Club", "Bilbao", "San Mamés"));
        listaEquipos.add(new Equipo(9, "RCD Mallorca", "Palma", "Visit Mallorca Estadi"));
        listaEquipos.add(new Equipo(10, "Girona FC", "Girona", "Montilivi"));

        // USUARIOS
        listaUsuarios.add(new Usuario("Mikel", "cordero"));
        listaUsuarios.add(new Usuario("Ion", "monzon"));
        listaUsuarios.add(new Usuario("Richard", "rueda"));
        listaUsuarios.add(new Usuario("Admin", "admin"));
    }

    private JPanel panelInicio() {
        JPanel p = new JPanel(new BorderLayout());

        // Superior Derecha: Registro
        JPanel norte = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnReg = new JButton("Registrarse");
        btnReg.addActionListener(e -> cardLayout.show(contenedor, "REGISTRO_FORM"));
        norte.add(btnReg);
        p.add(norte, BorderLayout.NORTH);

        // Centro: LOGO y Botones
        JPanel centro = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.insets = new Insets(20, 0, 20, 0);

        // Logo
        ImageIcon icon = new ImageIcon(RUTA_LOGO);
        JLabel lblLogo = new JLabel(icon);
        if (icon.getIconWidth() == -1) {
            lblLogo.setText("LALIGA PLUS");
            lblLogo.setFont(new Font("Arial", Font.ITALIC + Font.BOLD, 48));
        }
        gbc.gridy = 0;
        centro.add(lblLogo, gbc);

        // Botones
        JPanel panelBotones = new JPanel(new GridLayout(2, 1, 10, 10));
        JButton b1 = new JButton("Iniciar Sesión");
        JButton b2 = new JButton("Entrar como Invitado");
        b1.addActionListener(e -> cardLayout.show(contenedor, "LOGIN_FORM"));
        b2.addActionListener(e -> cardLayout.show(contenedor, "INVITADO"));
        panelBotones.add(b1); panelBotones.add(b2);

        gbc.gridy = 1;
        centro.add(panelBotones, gbc);

        p.add(centro, BorderLayout.CENTER);
        return p;
    }

    private JPanel panelRegistro() {
        JPanel p = new JPanel(new GridBagLayout());
        JPanel f = new JPanel(new GridLayout(3, 2, 10, 10));
        f.setBorder(BorderFactory.createTitledBorder("Nuevo LaLigaPlus.Usuario"));
        JTextField u = new JTextField(10); JPasswordField ps = new JPasswordField(10);
        JButton bG = new JButton("Crear"); JButton bV = new JButton("Atrás");
        f.add(new JLabel("LaLigaPlus.Usuario:")); f.add(u);
        f.add(new JLabel("Pass:")); f.add(ps);
        f.add(bV); f.add(bG);
        bG.addActionListener(e -> {
            listaUsuarios.add(new Usuario(u.getText(), new String(ps.getPassword())));
            JOptionPane.showMessageDialog(this, "LaLigaPlus.Usuario registrado.");
            cardLayout.show(contenedor, "INICIO");
        });
        bV.addActionListener(e -> cardLayout.show(contenedor, "INICIO"));
        p.add(f); return p;
    }

    private JPanel panelLogin() {
        JPanel p = new JPanel(new GridBagLayout());
        JPanel f = new JPanel(new GridLayout(3, 2, 10, 10));
        f.setBorder(BorderFactory.createTitledBorder("Login"));
        JTextField u = new JTextField(10); JPasswordField ps = new JPasswordField(10);
        JButton bE = new JButton("Entrar"); JButton bV = new JButton("Atrás");
        f.add(new JLabel("LaLigaPlus.Usuario:")); f.add(u);
        f.add(new JLabel("Pass:")); f.add(ps);
        f.add(bV); f.add(bE);
        bE.addActionListener(e -> {
            boolean ok = listaUsuarios.stream().anyMatch(user -> user.getUsername().equals(u.getText()) && user.getPassword().equals(new String(ps.getPassword())));
            if(ok) cardLayout.show(contenedor, "REGISTRADO");
            else JOptionPane.showMessageDialog(this, "Error de acceso", "Error", 0);
        });
        bV.addActionListener(e -> cardLayout.show(contenedor, "INICIO"));
        p.add(f); return p;
    }

    private JPanel panelEquipos(boolean reg) {
        JPanel p = new JPanel(new BorderLayout(15, 15));
        p.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        JLabel t = new JLabel(reg ? "BASE DE DATOS COMPLETA" : "VISTA INVITADO (LIMITADA)", 0);
        t.setFont(new Font("Arial", Font.BOLD, 18));
        p.add(t, BorderLayout.NORTH);

        String[] cols = {"ID", "Club", "Ciudad", "Estadio"};
        DefaultTableModel mod = new DefaultTableModel(cols, 0);
        int limit = reg ? listaEquipos.size() : 2;
        for(int i=0; i<limit; i++) mod.addRow(listaEquipos.get(i).toRow());

        p.add(new JScrollPane(new JTable(mod)), BorderLayout.CENTER);

        JPanel sur = new JPanel(new BorderLayout());
        if(!reg) {
            JLabel m = new JLabel("¡Regístrate para desbloquear los 10 equipos!", 0);
            m.setForeground(Color.RED); sur.add(m, BorderLayout.NORTH);
        }
        JButton bS = new JButton("Cerrar Sesión");
        bS.addActionListener(e -> cardLayout.show(contenedor, "INICIO"));
        sur.add(bS, BorderLayout.SOUTH);
        p.add(sur, BorderLayout.SOUTH);
        return p;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LaLigaPlusApp());
    }
}
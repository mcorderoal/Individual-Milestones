package Hitos.H2;

import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.*;

public class H2 extends JFrame implements ActionListener {
    private JComboBox<String> comboFiles;
    private JTextArea textArea;
    private JButton btnClear, btnClose;

    public H2() {
        setTitle("Test Events: Files");
        setSize(600, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        String[] fileNames = {"python.txt", "c.txt", "java.txt"};
        comboFiles = new JComboBox<>(fileNames);
        comboFiles.setBounds(20, 20, 200, 30);
        comboFiles.addActionListener(this);
        add(comboFiles);

        // Clear Button
        btnClear = new JButton("Clear");
        btnClear.setBounds(230, 20, 80, 30);
        btnClear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textArea.setText("");
            }
        });
        add(btnClear);

        // Text area
        textArea = new JTextArea();
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setBounds(330, 20, 240, 300);
        add(scrollPane);

        // Close Button
        btnClose = new JButton("Close");
        btnClose.setBounds(250, 340, 100, 30);
        btnClose.addActionListener(this);
        add(btnClose);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnClose) {
            System.exit(0);
        }
        else if (e.getSource() == comboFiles) {
            String selectedFile = (String) comboFiles.getSelectedItem();
            try {
                String content = new String(Files.readAllBytes(Paths.get(selectedFile)));
                textArea.setText(content);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this,
                        "Error: El archivo '" + selectedFile + "' no existe.",
                        "Error de archivo",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new H2().setVisible(true);
        });
    }
}
package Hitos.H3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class H3 extends JFrame implements ActionListener {
    private static final String CARPETA = "imagenes/";

    private JComboBox Jimages;
    private JLabel Jlabel;
    private JTextField Jtext;
    private JCheckBox Jbox;
    private JButton Jbutton;

    public H3() {
        String password = JOptionPane.showInputDialog(null, "Input password", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (password == null || !password.equals("damocles")) {
            System.exit(0);
        }

        setTitle("Swing - Example 2");
        setSize(300, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        Jimages = new JComboBox();
        load_combo();

        Jlabel = new JLabel();
        Jlabel.setPreferredSize(new Dimension(250, 200));

        Jbox = new JCheckBox("Save your comment", true);
        Jtext = new JTextField(20);
        Jbutton = new JButton("SAVE");

        add(Jimages);
        add(Jlabel);
        add(Jbox);
        add(Jtext);
        add(Jbutton);

        Jimages.addActionListener(new ComboListener());

        Jbutton.addActionListener(this);

        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                JOptionPane.showMessageDialog(null, "¡Adiós!");
            }
        });

        actualizarImagen();

        setVisible(true);
    }

    private void load_combo() {
        File archivo1 = new File(CARPETA);
        String[] fotos = archivo1.list();

        if (fotos != null) {
            for (String nombre : fotos) {
                if (nombre.toLowerCase().endsWith(".jpg") || nombre.toLowerCase().endsWith(".png")) {
                    Jimages.addItem(nombre);
                }
            }
        }
    }

    private void actualizarImagen() {
        String nombre = (String) Jimages.getSelectedItem();
        if (nombre != null) {
            ImageIcon icono = new ImageIcon(CARPETA + nombre);
            Image img = icono.getImage().getScaledInstance(250, 200, Image.SCALE_SMOOTH);
            Jlabel.setIcon(new ImageIcon(img));
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (Jbox.isSelected()) {
            String nombreImagen = (String) Jimages.getSelectedItem();
            String comentario = Jtext.getText();

            String nombreArchivo = nombreImagen + ".txt";

            try {
                FileWriter fw = new FileWriter(nombreArchivo, true);
                PrintWriter pw = new PrintWriter(fw);
                pw.println(nombreImagen + " + " + comentario);
                pw.close();

                JOptionPane.showMessageDialog(this, "Guardado correctamente");
                Jtext.setText("");
            } catch (IOException ex) {
                System.out.println("Error al guardar");
            }
        }
    }

    class ComboListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            actualizarImagen();
        }
    }

    public static void main(String[] args) {
        new H3();
    }
}